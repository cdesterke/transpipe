#' @title pcatrans

#' @param group group column from phenotype file
#' @usage pcatrans(ok,pheno,pal="Set1")
#' @examples pcatrans(ok,pheno,group="group",pal="Set1")
#' @examples ## palette examples : Set1, Set2, Set3, Pastel1, Pastel2, Dark1, Dark2, Accent


pcatrans<-function(data,pheno,group="group",pal="Dark2"){

  #install require R packages if necessary and load them
  if(!require(ggfortify)){
    install.packages("ggfortify")
    library(ggfortify)}

# transpose data
trans<-t(data)

# perform PCA on transposed data
pca<-prcomp(trans,scale=TRUE)

# graphical output
autoplot(pca,data=pheno,colour=group,label=F, label.size=0,size=4)+
  theme_classic(base_size = 16)+ scale_color_brewer(palette=pal)


}
