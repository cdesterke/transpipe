#' @title bestheat

#' @param res results from limma deg analysis
#' @param data transcriptome matrix
#' @param q threshold of q-values
#' @param up up threshold for fold change
#' @param down down treshold for fold change
#' @param font font size
#' @usage bestheat(res,ok,q=0.8,up=0.001,font=10)
#' @examples bestheat(res,ok,q=0.8,up=0.001,font=10)
#' @examples ## limmares.tsv filtrated result output in the directory



bestheat<-function(res,data,q=0.05,up=1,down=-1,font=6){

  if(!require(dplyr)){install.packages("dplyr")}
  library(dplyr)
  if(!require(pheatmap)){install.packages("pheatmap")}
  library(pheatmap)


  res%>%filter(adj.P.Val<q)%>% filter(logFC > up | logFC < down )->df


  process<-merge(df,data,by="row.names")

  row.names(process)<-process$Row.names


  process<-process[,8:ncol(process)]

  pheatmap(process, color = colorRampPalette(c("navy", "white", "firebrick3"))(50),
           annotation=pheno, fontsize =font,cutree_rows=1,
           cutree_col=1,clustering_method = "ward.D2",
           clustering_distance_cols = "euclidean",
           clustering_distance_rows = "euclidean",
           show_colnames=F,
           show_rownames=T,
           annotation_names_col=T,
           annotation_names_row = F)


  write.table(df,file="limmares.tsv",sep="\t")

}
